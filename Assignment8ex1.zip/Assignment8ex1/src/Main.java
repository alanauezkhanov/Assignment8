import java.util.ArrayList;
import java.util.List;

interface Subject {
    void registerInvestor(Investor investor);
    void unregisterInvestor(Investor investor);
    void notifyInvestors();
}

class Stock implements Subject {
    private String symbol;
    private float price;
    private List<Investor> investors;

    public Stock(String symbol, float price) {
        this.symbol = symbol;
        this.price = price;
        this.investors = new ArrayList<>();
    }

    public void updatePrice(float price) {
        this.price = price;
        notifyInvestors();
    }

    @Override
    public void registerInvestor(Investor investor) {
        investors.add(investor);
    }

    @Override
    public void unregisterInvestor(Investor investor) {
        investors.remove(investor);
    }

    @Override
    public void notifyInvestors() {
        for (Investor investor : investors) {
            investor.update(this, price);
        }
    }

    public float getPrice() {
        return price;
    }

    public String getSymbol() {
        return symbol;
    }
}

interface Observer {
    void update(Stock stock, float price);
}

class Investor implements Observer {
    private String name;
    private List<Stock> stocks;

    public Investor(String name) {
        this.name = name;
        this.stocks = new ArrayList<>();
    }

    public void investInStock(Stock stock) {
        stock.registerInvestor(this);
        stocks.add(stock);
    }

    public void divestFromStock(Stock stock) {
        stock.unregisterInvestor(this);
        stocks.remove(stock);
    }

    @Override
    public void update(Stock stock, float price) {
        System.out.println(name + " received notification: " + stock.getSymbol() + " price changed to " + price);
    }
}

public class Main {
    public static void main(String[] args) {
        Stock apple = new Stock("AAPL", 150.0f);
        Stock google = new Stock("GOOGL", 2500.0f);

        Investor investor1 = new Investor("John");
        Investor investor2 = new Investor("Alice");

        investor1.investInStock(apple);
        investor1.investInStock(google);

        investor2.investInStock(apple);

        apple.updatePrice(155.0f);
        google.updatePrice(2550.0f);

        investor1.divestFromStock(google);

        google.updatePrice(2600.0f);
    }
}
